﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace NewIT_Laba4_Client
{
    class Program
    {
        //Флаг для циклического выполнения основного функционала
        static bool flag = true;

        static void Main(string[] args)
        {
            try
            {
                SendMessageFromSocket();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }

        //Отправка числа (int)
        public static void SendNumber(Socket socket, int value)
        {
            byte[] data;
            //Представляем число в виде байтов
            data = BitConverter.GetBytes(value);
            //Отправляем число
            socket.Send(data);
        }

        //Получить число (int)
        public static int ReceiveNumber(Socket socket)
        {
            int number;
            //Выделяем размер под INT
            byte[] data = new byte[4];
            //Получаем данные
            socket.Receive(data);
            //Конвертируем в INT
            number = BitConverter.ToInt32(data, 0);
            return number;
        }

        //Отправить строку произвольной длины
        public static void SendString(Socket socket, string input)
        {
            //Перевод в byte
            byte[] data = Encoding.Unicode.GetBytes(input);
            //Определение размера
            int dataSize_int = data.Length;
            //Представление размера в виде byte
            byte[] dataSize_byte = BitConverter.GetBytes(dataSize_int);
            socket.Send(dataSize_byte);
            socket.Send(data);
        }

        //Получить строку произвольной длины
        public static string ReceiveString(Socket socket)
        {
            //Выделяем место под размер
            byte[] stringSize_byte = new byte[4];
            //Получаем размер
            socket.Receive(stringSize_byte);
            //Перевод размера в int
            int stringSize_int = BitConverter.ToInt32(stringSize_byte, 0);
            //Выделение места под данные
            byte[] data = new byte[stringSize_int];
            //Получаем данные
            socket.Receive(data);
            //Конвертируем в string
            string receivedString = Encoding.Unicode.GetString(data);
            return receivedString;
        }

        //Отправить двумерный массив
        public static void SendArray(Socket socket, int[,] array)
        {
            //Число строк
            int N = array.GetLength(0);
            //Число столбцов
            int M = array.GetLength(1);
            

            //Cчётчик элемента
            int counter = 0;

            //Определяем одномерный массив, в котором будут содержаться последовательно все элементы двумерного 
            int[] sendingArray = new int[array.Length];
            for (int i =0; i < N; i++)
            {
                for(int j = 0; j < M; j++)
                {
                    sendingArray[counter] = array[i, j];
                    counter++;
                }
            }

            byte[] data = new byte[sendingArray.Length * sizeof(int)];
            Buffer.BlockCopy(sendingArray, 0, data, 0, data.Length);
            //Отправляем размерность строки 
            SendNumber(socket, M);
            //Отправляем размер массива байтов
            SendNumber(socket, data.Length);
            //Отправляем сам массив байтов
            socket.Send(data);
        }

        //Получить двумерный массив
        public static int[,] ReceiveArray(Socket socket)
        {
            //Получаем размерость строки - число столбцов (итогового двумерного массива)
            int M = ReceiveNumber(socket);
            //Получаем размерность массива байтов
            int dataSizeBytes = ReceiveNumber(socket);

            //Инициализация массива байтов
            byte[] dataBytes = new byte[dataSizeBytes];
            socket.Receive(dataBytes);
            //Определение размера массива int
            int dataSize = dataSizeBytes / sizeof(int);
            //Инициализация массива int
            int[] data = new int[dataSize];

            //Заполнение одномерного массива int
            for (int i=0; i<dataSize; i++)
            {
                //удалено
            }

            //Получаем число строк (итогового двумерного массива)
            int N = dataSize / M;
            //Счётчик для передвижения по одномерному массиву
            int counter = 0;
            //Инициализация двумерного массива
            int[,] sendingData = new int[N, M]; 
            for (int i = 0; i < N; i++)
            {
                //удалено
            }

            return //удалено;
        }
        
        //Печать меню
        static void MenuText()
        {
            Console.WriteLine("МЕНЮ");
            Console.WriteLine("-------------------------------------------------------------");
            Console.WriteLine("1) Разминка 1. Ввести 3 числа, получить их квадраты");
            Console.WriteLine("2) Разминка 2. Ввести 2 строки, получить их конкатенацию");
            Console.WriteLine("3) Разминка 3. Команды серверу");
            Console.WriteLine("4) Задание 1. Ввести 3 числа, узнать сколько из них кратны 3");
            Console.WriteLine("5) Задание 2. Ввести массив NxM. Отправить на сервер и получить его обратно");
            Console.WriteLine("6) Завершить работу");
            Console.WriteLine("-------------------------------------------------------------");
        }

        //Действия меню
        static void MenuAction(Socket socket)
        {
            Console.Write("Введите номер пункта меню:  ");
            int typeOfCommand = Int32.Parse(Console.ReadLine());
            Console.WriteLine();
            switch (typeOfCommand)
            {
                case 1:
                    Training_1(socket);
                    break;

                case 2:
                    Training_2(socket);
                    break;

                case 3:
                    Training_3(socket);
                    break;

                case 4:
                    MainTask_1(socket);
                    break;

                case 5:
                    MainTask_2(socket);
                    break;
                case 6:
                    flag = false;
                    break;
            }
        }

        // Разминка 1.
        // Ввести 3 числа, получить их квадраты
        static void Training_1(Socket socket)
        {
            //удалено
        }

        // Разминка 2
        // Ввести 2 строки, получить их конкатенацию
        static void Training_2(Socket socket)
        {
            //удалено

        }

        //Разминка 3
        //Вызов подменю и тд
        static void Training_3(Socket socket)
        {
            //удалено

        }

        // Задание 1
        // Ввести 3 числа, получить количество кратных трём
        static void MainTask_1(Socket socket)
        {
            //удалено
        }

        //Задание 2
        //Ввести двумерный массив, получить его обратно с сервера
        static void MainTask_2(Socket socket)
        {
           //удалено
        }

        //Печать двумерного массива
        static void PrintArray(int[,] array)
        {
            //удалено
        }
        
        static void SendMessageFromSocket()
        {

            Socket socket = new Socket(SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1213);

            // Соединяем сокет с удаленной точкой
            socket.Connect(ip);
            // Выводим текст меню
            MenuText();
            // Действия с меню
            MenuAction(socket);
            Console.WriteLine();

            //Рекурсия
            if (flag == true)
            {
                SendMessageFromSocket();
            }
            
            // Освобождаем сокет
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();

            Console.WriteLine("Программа завершена. Нажмите что-нибудь!");
            Console.ReadKey();
            
        }
    }
}
