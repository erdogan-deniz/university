﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace NewIT_Laba4_Server
{
    class Program
    {
        //Отправка числа (int)
        public static void SendNumber(Socket socket, int value)
        {
            byte[] data;
            //Представляем число в виде байтов
            data = BitConverter.GetBytes(value);
            //Отправляем число
            socket.Send(data);
        }

        //Получить число (int)
        public static int ReceiveNumber(Socket socket)
        {
            int number;
            //Выделяем размер под INT
            byte[] data = new byte[4];
            //Получаем данные
            socket.Receive(data);
            //Конвертируем в INT
            number = BitConverter.ToInt32(data, 0);
            return number;
        }

        //Отправить строку произвольной длины
        public static void SendString(Socket socket, string input)
        {
            //Перевод в byte
            byte[] data = Encoding.Unicode.GetBytes(input);
            //Определение размера
            int dataSize_int = data.Length;
            //Представление размера в виде byte
            byte[] dataSize_byte = BitConverter.GetBytes(dataSize_int);
            socket.Send(dataSize_byte);
            socket.Send(data);
        }

        //Получить строку произвольной длины
        public static string ReceiveString(Socket socket)
        {
            //Выделяем место под размер
            byte[] stringSize_byte = new byte[4];
            //Получаем размер
            socket.Receive(stringSize_byte);
            //Перевод размера в int
            int stringSize_int = BitConverter.ToInt32(stringSize_byte, 0);
            //Выделение места под данные
            byte[] data = new byte[stringSize_int];
            //Получаем данные
            socket.Receive(data);
            //Конвертируем в string
            string receivedString = Encoding.Unicode.GetString(data);
            return receivedString;
        }

        //Отправить двумерный массив
        public static void SendArray(Socket socket, int[,] array)
        {
            //Число строк
            int N = array.GetLength(0);
            //Число столбцов
            int M = array.GetLength(1);

            //Cчётчик элемента
            int counter = 0;

            //Определяем одномерный массив, в котором будут содержаться последовательно все элементы двумерного 
            int[] sendingArray = new int[array.Length];
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    sendingArray[counter] = array[i, j];
                    counter++;
                }
            }

            byte[] data = new byte[sendingArray.Length * sizeof(int)];
            Buffer.BlockCopy(sendingArray, 0, data, 0, data.Length);
            //Отправляем размерность строки 
            SendNumber(socket, M);
            //Отправляем размер массива байтов
            SendNumber(socket, data.Length);
            //Отправляем сам массив байтов
            socket.Send(data);
        }

        //Получить двумерный массив
        public static int[,] ReceiveArray(Socket socket)
        {
            //Получаем размерость строки - число столбцов (итогового двумерного массива)
            int M = ReceiveNumber(socket);
            //Получаем размерность массива байтов
            int dataSizeBytes = ReceiveNumber(socket);

            //Инициализация массива байтов
            byte[] dataBytes = new byte[dataSizeBytes];
            socket.Receive(dataBytes);
            //Определение размера массива int
            int dataSize = dataSizeBytes / sizeof(int);
            //Инициализация массива int
            int[] data = new int[dataSize];

            //Заполнение одномерного массива int
            for (//удалено)
            {
                //удалено
            }

            //Получаем число строк (итогового двумерного массива)
            int N = dataSize / M;
            //Счётчик для передвижения по одномерному массиву
            int counter = 0;
            //Инициализация двумерного массива
            int[,] sendingData = new int[N, M];

            for (//удалено)
            {
                //удалено
            }

            //return удалено;
        }

        //Печать двумерного массива
        static void PrintArray(int[,] array)
        {
            //удалено
        }

        static void ServerAction(Socket socket, int typeOfCommand)
        {
            switch (typeOfCommand)
            {
                case 1:
                    Console.WriteLine("Начинаю выполнять Training_1_Server (Разминка 1)");
                    Training_1_Server(socket);
                    break;

                case 2:
                    Console.WriteLine("Начинаю выполнять Training_2_Server (Разминка 2)");
                    Training_2_Server(socket);
                    break;

                case 3:
                    Console.WriteLine("Начинаю выполнять Training_3_Server (Разминка 3)");
                    Training_3_Server(socket);
                    break;

                case 4:
                    Console.WriteLine("Начинаю выполнять MainTask_1_Server (Заданеие 1)");
                    MainTask_1_Server(socket);
                    break;

                case 5:
                    Console.WriteLine("Начинаю выполнять MainTask_2_Server (Заданеие 2)");
                    MainTask_2_Server(socket);
                    break;
            }
        }

        //Разминка 1
        static void Training_1_Server(Socket socket)
        {
            //удалено
        }

        //Разминка 2
        static void Training_2_Server(Socket socket)
        {
            //удалено
        }

        static void Training_3_Server(Socket socket)
        {
            //удалено
        }

        //Задание 1
        static void MainTask_1_Server(Socket socket)
        {
            //удалено

        }

        static void MainTask_2_Server(Socket socket)
        {
            //удалено

        }

        static void Main(string[] args)
        {
            // Создаем сокет Tcp/Ip
            Socket socket = new Socket(SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1213);

            // Назначаем сокет локальной конечной точке и слушаем входящие сокеты
            try
            {
                socket.Bind(ip);
                socket.Listen(10);

                // Начинаем слушать соединения
                while (true)
                {
                    Console.WriteLine("Ожидаем соединение через порт {0}", ip);

                    // Программа приостанавливается, ожидая входящее соединение
                    Socket handler = socket.Accept();
                    //string data = null;

                    // Дождались клиента, пытающегося с нами соединиться
                    int typeOfCommand = ReceiveNumber(handler);
                    ServerAction(handler, typeOfCommand);

                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
