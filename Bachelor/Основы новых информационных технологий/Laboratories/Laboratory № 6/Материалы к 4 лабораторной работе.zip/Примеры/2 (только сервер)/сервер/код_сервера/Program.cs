﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//для сокета
using System.Net;
using System.Net.Sockets;

//для потока
using System.Threading;

using SocketLib;

//для Task
using System.Threading.Tasks;

namespace Server
{

    class ClientConnection
    {
        public Socket socket;
        public string name;

        public List<string> messagesToSend = new List<string>();

        public delegate void NewMessageDelegate(ClientConnection sender, string msg);
        public event NewMessageDelegate NewMessage;

        public event Action Diconnect;

        public void sendMessages()
        {

            Thread t = new Thread(delegate()
                {
                    while (socket.Connected)
                    {

                        try
                        {
                            if (messagesToSend.Count == 0)
                                Thread.Sleep(1);
                            while (messagesToSend.Count != 0)
                            {
                                SocketFunctions.SendInt32(socket, (int)Commands.NewMessage);
                                SocketFunctions.SentString(socket, messagesToSend[0]);
                                messagesToSend.RemoveAt(0);
                            }
                        }

                        catch (Exception ex)
                        {
                            IPEndPoint ip = (IPEndPoint)socket.RemoteEndPoint;
                            Console.WriteLine("Sending Error! " + ip.Address.ToString() + " " + name);
                            Console.WriteLine(ex);
                        }

                    }


                });

            t.Start();
        }

        public void listen()
        {
            Thread t = new Thread(delegate ()
                 {
                    string _ip = ((IPEndPoint)(socket.RemoteEndPoint)).Address.ToString();
                    Console.WriteLine("{0} under {1} has been connected!", name, _ip);

                     while (socket.Connected)
                     {
                         try
                         {
                             int cmd_i = SocketFunctions.ReciveInt32(socket);
                             Commands cmd = (Commands)cmd_i;

                             switch (cmd)
                             {
                                 case Commands.NewMessage:
                                     {
                                         string msg = SocketFunctions.ReciveString(socket);
                                         if (NewMessage != null)
                                             NewMessage(this, msg);
                                         break;
                                     }
                                case Commands.Disconnect:
                                    {
                                         socket.Shutdown(SocketShutdown.Both);
                                         socket.Close();
                                       break;
                                    }
                             }
                         }
                         catch (Exception ex)
                         {
                                 IPEndPoint ip = (IPEndPoint)socket.RemoteEndPoint;
                                 Console.WriteLine("Reading Error! "+ip.Address.ToString() +" "+name);
                                 Console.WriteLine(ex);
                         }

                     }

                     Console.WriteLine("{0} under {1} has been disconnected!", name, _ip);
                     if (this.Diconnect != null)
                         Diconnect();
                 });

            t.Start();
        }
    }

    class Program
    {

        static Thread ListenerThread;
        static List<ClientConnection> connectedClients = new List<ClientConnection>();
       
        static void Main(string[] args)
        {

            ListenerThread = new Thread(Program.startListen);
            ListenerThread.Start();
            ListenerThread.Join();

            Console.ReadLine();
        }
              

        static void startListen()
        {
           
            IPEndPoint ip = new IPEndPoint(IPAddress.Any, 1213);
            Socket listener = new Socket(IPAddress.Any.AddressFamily ,SocketType.Stream, ProtocolType.Tcp);

            try
            {
                
                listener.Bind(ip);
                listener.Listen(0);

                while (true)
                {
                    Socket s = listener.Accept();
                    ClientConnection cn = new ClientConnection();

                    string name = string.Empty;
                    try
                    {
                        name = SocketFunctions.ReciveString(s);

                        cn.name = name;
                        cn.socket = s;

                        cn.NewMessage += incomingMessage;
                        cn.NewMessage += (c, m) =>
                            {
                                string _ip = ((IPEndPoint)(c.socket.RemoteEndPoint)).Address.ToString();
                                Console.WriteLine("{0}({1}): {2}", c.name, _ip, m);
                            };

                        cn.Diconnect += () =>
                             {
                                 connectedClients.Remove(cn);
                             };

                        cn.listen();
                        cn.sendMessages();

                        connectedClients.Add(cn);
                        
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }          
                        
        }

       static void incomingMessage(ClientConnection c, string msg)
        {
            foreach(ClientConnection cl in connectedClients)
            {
                //if (cl == c)
                //    continue;
                string m = c.name +"%&%" + msg;
                cl.messagesToSend.Add(m);
            }
        }
        

    }
}
