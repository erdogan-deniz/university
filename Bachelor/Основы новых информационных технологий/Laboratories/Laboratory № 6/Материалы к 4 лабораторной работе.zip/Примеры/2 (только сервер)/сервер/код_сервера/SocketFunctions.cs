﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;

//для Encoding
using System.IO;

namespace SocketLib
{

    public enum Commands
    {
        NewMessage,Disconnect
    }

    public class SocketFunctions
    {
        //Отправка int
        public static void SendInt32(Socket s, int value)
        {
            //пепеводим число в массив байтов
            byte[] b = BitConverter.GetBytes(value);

            //Отправляем байты
                s.Send(b,0,sizeof(Int32),SocketFlags.None);
        }

        //Получение int
        public static int ReciveInt32(Socket s)
        {
            //Выделяем массив байтов для хранения int
            byte[] b = new byte[sizeof(Int32)];

            //Получаем данные
            s.Receive(b, sizeof(Int32), SocketFlags.None);

            //Переводим полученные данные в int и возвращаем
            return BitConverter.ToInt32(b, 0);
        }

        public static void SendBytes(Socket s, byte[] data)
        {
            SendInt32(s, data.Length);
            s.Send(data);
        }

        public static byte[] ReciveBytes(Socket s)
        {
            int size = ReciveInt32(s);
            byte[] b = new byte[size];
            s.Receive(b, size, SocketFlags.None);
            return b;
        }

        public static void SentString(Socket s, string value)
        {
            byte[] b = Encoding.Unicode.GetBytes(value);
            SendBytes(s,b);       
        }

        public static string ReciveString(Socket s)
        {
            byte[] b = ReciveBytes(s);
            return Encoding.Unicode.GetString(b);            
        }

        
    }
}
