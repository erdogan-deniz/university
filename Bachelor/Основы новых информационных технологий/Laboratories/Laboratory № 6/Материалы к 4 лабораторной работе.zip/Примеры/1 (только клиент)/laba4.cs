﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Net.Sockets;

using System.Threading;

namespace PlayWithSockets
{
    class Program
    {

        static Socket listener;
        
        static void server()
        {

            //Клиент подлючился, можем общатся с ним через этот сокет
            Socket socket = listener.Accept();

            //Писать код сервера тут!!!!!


            string str = "Я ооочень большая строка";

            //Для начала переведем строку в массив байтов.
            byte[] data = Encoding.Unicode.GetBytes(str);

            //размер получившегося массива байтов.
            int dataSize = data.Length;

            //Теперь отправим на сервер размер данных
            byte[] dataSize_bytes = BitConverter.GetBytes(dataSize);
            socket.Send(dataSize_bytes);

            //Отправляем сами данные
            socket.Send(data);




            //Разрыв
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();

        }
        static void client()
        {
            Socket socket = new Socket(SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1213);
            socket.Connect(ip);


            //Писать код клиента тут!!1

            //получаем размер данных
            byte[] size_bytes = new byte[4];
            socket.Receive(size_bytes);
            int size = BitConverter.ToInt32(size_bytes, 0);

            //получаем сами данные
            byte[] data = new byte[size];
            socket.Receive(data);

            //переводим в строку
            string str = Encoding.Unicode.GetString(data);
            Console.WriteLine(str);





        }

        static void Main(string[] args)
        {

            //создаем сервер:

            //сначала то, на что сервак будет биндится (адрес и порт)
            IPEndPoint ip = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1213);

            //затем "прослушивающий сокет"
            listener = new Socket(IPAddress.Any.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                //биндимся!
                listener.Bind(ip);

                //начинаем слушать порт
                listener.Listen(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Не удалось запустить сервер!");
                Console.ReadKey();
                return;
            }

            //объявляем потоки для сервера и клиента
            Thread serverThread = new Thread(server);
            Thread clientThread = new Thread(client);

            //стартуем потоки для сервера и клиента
            serverThread.Start();
            clientThread.Start();

            //ожидаем завершения клиентского потока
            clientThread.Join();

            //ожидаем завершения серверного потока
            serverThread.Join();

            //Вот и все, ребята!
            Console.WriteLine("Программа завершена. Пресс эни кей!");
            Console.ReadKey();
        }
    }


   
}
